<?php
$string['pluginname'] = "Moodle Rest Additional WS support";
